from django.urls import path
from . import views

urlpatterns = [
    # Add category-related URLs here if needed
    # Example: path('', views.category_list, name='category_list'),
]