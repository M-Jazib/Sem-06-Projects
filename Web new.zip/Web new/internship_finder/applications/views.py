from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Application
from internships.models import Internship

@login_required
def apply_internship(request, internship_id):
    internship = Internship.objects.get(id=internship_id)
    if Application.objects.filter(user=request.user, internship=internship).exists():
        messages.warning(request, 'You have already applied for this internship.')
    else:
        Application.objects.create(user=request.user, internship=internship)
        messages.success(request, 'Application submitted successfully!')
    return redirect('internship_list')

@login_required
def application_list(request):
    applications = Application.objects.filter(user=request.user)
    return render(request, 'applications/application_list.html', {'applications': applications})