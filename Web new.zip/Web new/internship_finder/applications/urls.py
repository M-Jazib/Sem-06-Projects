from django.urls import path
from . import views

urlpatterns = [
    path('apply/<int:internship_id>/', views.apply_internship, name='apply_internship'),
    path('my-applications/', views.application_list, name='application_list'),
]