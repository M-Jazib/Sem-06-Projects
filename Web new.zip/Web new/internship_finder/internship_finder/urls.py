from django.contrib.auth.views import LogoutView

"""
URL configuration for internship_finder project.
"""

from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('core.urls')),
    path('internships/', include('internships.urls')),
    path('accounts/', include('users.urls')),
    path('applications/', include('applications.urls')),
    path('categories/', include('categories.urls')),
    path('', include('internships.urls')),  # or whatever your app is called
     path('logout/', LogoutView.as_view(), name='logout'),
    
]