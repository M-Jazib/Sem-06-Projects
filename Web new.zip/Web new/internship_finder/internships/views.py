from django.shortcuts import render
from django.db.models import Q
from .models import Internship
from categories.models import Category, InternshipType

def applications_view(request):
    # Fetch user applications, e.g. from a model Application if you have one
    # applications = Application.objects.filter(user=request.user)
    # return render(request, 'applications/applications_list.html', {'applications': applications})

    return render(request, 'applications/applications_list.html')
# internships/views.py

from django.shortcuts import render
from .models import Internship

def internship_list(request):
    internships = Internship.objects.all()
    return render(request, 'internships/internship_list.html', {'internships': internships})



def internship_list(request):
    internships = Internship.objects.all()
    query = request.GET.get('q')
    category_id = request.GET.get('category')
    type_id = request.GET.get('type')
    location = request.GET.get('location')

    if query:
        internships = internships.filter(
            Q(title__icontains=query) | Q(company__icontains=query)
        )
    if category_id:
        internships = internships.filter(category__id=category_id)
    if type_id:
        internships = internships.filter(internship_type__id=type_id)
    if location:
        internships = internships.filter(location__icontains=location)

    categories = Category.objects.all()
    types = InternshipType.objects.all()
    locations = Internship.objects.values_list('location', flat=True).distinct()

    context = {
        'internships': internships,
        'query': query or '',
        'categories': categories,
        'types': types,
        'locations': locations,
        'selected_category': category_id or '',
        'selected_type': type_id or '',
        'selected_Location': location or '',
    }
    return render(request, 'internships/internship_list.html', context)