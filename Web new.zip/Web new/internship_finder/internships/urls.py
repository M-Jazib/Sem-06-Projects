# internships/urls.py (or your app's urls.py)

from django.urls import path
from . import views

urlpatterns = [
    # other URLs...
    path('applications/', views.applications_view, name='applications'),
    path('internships/', views.internship_list, name='internship_list'),
    
]
