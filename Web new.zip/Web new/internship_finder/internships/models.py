from django.db import models
from categories.models import Category, InternshipType

class Internship(models.Model):
    title = models.CharField(max_length=200)
    company = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True)
    internship_type = models.ForeignKey(InternshipType, on_delete=models.SET_NULL, null=True)
    description = models.TextField()
    posted_date = models.DateField(auto_now_add=True)
    apply_link = models.URLField(blank=True)

    def __str__(self):
        return f"{self.title} at {self.company}"

    class Meta:
        ordering = ['-posted_date']