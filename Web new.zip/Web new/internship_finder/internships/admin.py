from django.contrib import admin
from .models import Internship
from internships.models import Internship
Internship.objects.all().count()


@admin.register(Internship)
class InternshipAdmin(admin.ModelAdmin):
    list_display = ('title', 'company', 'location', 'category', 'posted_date')
    list_filter = ('category', 'internship_type', 'location')
    search_fields = ('title', 'company', 'description')