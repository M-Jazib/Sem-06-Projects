# No models needed for core app
pass