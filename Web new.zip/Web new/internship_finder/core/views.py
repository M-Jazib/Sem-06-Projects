from django.shortcuts import render
from internships.models import Internship
from users.models import CustomUser
from categories.models import Category

def home(request):
    featured_internships = Internship.objects.all().order_by('-posted_date')[:4]
    categories = Category.objects.all()[:6]  # Top 6 categories
    testimonials = [
        {'name': 'Sarah J.', 'text': 'Landed my dream internship in just a week!'},
        {'name': 'Michael R.', 'text': 'The filters made finding internships so easy.'},
        {'name': 'Emily T.', 'text': 'Highly recommend for students seeking opportunities!'}
    ]
    stats = {
        'internships': Internship.objects.count(),
        'users': CustomUser.objects.count(),
        'applications': 500  # Placeholder
    }
    return render(request, 'core/home.html', {
        'featured_internships': featured_internships,
        'categories': categories,
        'testimonials': testimonials,
        'stats': stats
    })